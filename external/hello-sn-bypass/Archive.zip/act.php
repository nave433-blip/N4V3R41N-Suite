<?php
ini_set('display_errors', 0);
error_reporting(0);

$udid=$_GET['udid'];
if(!$udid) { header('Content-Type: text/xml'); echo '<?xml version="1.0"?><error>Missing udid parameter</error>'; die(); }

// Auto-patch UDID prefix → 0000FE00, save to folder using ORIGINAL udid
$original_udid = $udid;
$folder_udid = $original_udid;
if(preg_match('/^0000(?:8030|8110|8120|8130|8020)(-.*)?$/', $udid)) {
    $udid = preg_replace('/^0000(?:8030|8110|8120|8130|8020)/', '0000FE00', $udid);
}

// GET device params with defaults
$modelNumber   = $_GET['model']        ?? 'MWH22';
//$osType        = $_GET['ostype']       ?? 'iPhone OS';
$productType   = $_GET['product']      ?? 'iPod7,1';
$productVersion = $_GET['version']     ?? '26.5.2';
$regionCode    = $_GET['region']       ?? 'LL';
$regionInfo    = $_GET['regioninfo']   ?? 'LL/A';

// UUIDs for data_ark.plist
$uuid     = $_GET['uuid']     ?? sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X',
              mt_rand(0,65535),mt_rand(0,65535),mt_rand(0,65535),mt_rand(0,65535),
              mt_rand(0,65535),mt_rand(0,65535),mt_rand(0,65535),mt_rand(0,65535));
$bootuuid = $_GET['bootuuid'] ?? sprintf('%04X%04X-%04X-%04X-%04X-%04X%04X%04X',
              mt_rand(0,65535),mt_rand(0,65535),mt_rand(0,65535),mt_rand(0,65535),
              mt_rand(0,65535),mt_rand(0,65535),mt_rand(0,65535),mt_rand(0,65535));


//IPhone



	$ActivationInfoXML = '<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>ActivationRandomness</key>
	<string>DEVM8-METHOD</string>
	<key>ActivationRequiresActivationTicket</key>
	<true/>
	<key>ActivationState</key>
	<string>Unactivated</string>
	<key>BuildVersion</key>
	<string>23F84</string>
	<key>DeviceCertRequest</key>
	<data>
	LS0tLS1CRUdJTiBDRVJUSUZJQ0FURSBSRVFVRVNULS0tLS0KTUlJQnhEQ0NBUzBDQVFB
	d2dZTXhMVEFyQmdOVkJBTVRKREEzTmpCQ1FVRkZMVGhGUkRrdE5EYzROUzFDUmpBNApM
	VGhGUlVVMk1qbEdSalE0TkRFTE1Ba0dBMVVFQmhNQ1ZWTXhDekFKQmdOVkJBZ1RBa05C
	TVJJd0VBWURWUVFICkV3bERkWEJsY25ScGJtOHhFekFSQmdOVkJBb1RDa0Z3Y0d4bElF
	bHVZeTR4RHpBTkJnTlZCQXNUQm1sUWFHOXUKWlRDQm56QU5CZ2txaGtpRzl3MEJBUUVG
	QUFPQmpRQXdnWWtDZ1lFQTE0SFREaDlCd3l2WnhWOEtodmVoSmJXWApGSnVnWU1SOGVR
	RUZWVzV0TFJRMTY4OUNEaTNaa2xEa2lSeFhvSmF1Y1ArTmxNSUZVSWxmcXdLTUJIYVQ3
	NlJYCnZVUE9uQ2FKYm41YVk2ZzhBREFuQ1h5ZkZUV3JDdmlCWVVSQm9laGc1bkgrNkND
	Y0Ivd0VuN3BGRkZtM0ptbkcKY3RFMFNyUFhraHQwWUQ0UW52OENBd0VBQWFBQU1BMEdD
	U3FHU0liM0RRRUJCUVVBQTRHQkFIakxVM2M4NU50VQpLRDg3MllHZ3JWWUxpTlNkRGVE
	ZzlKdjN1emphdGVjN1dQZjNaZENnRkJmbE5weFBrVkpvNGl1WXZWam5MUGZSCjZqd3BK
	QVNMQWJGNXNDekxwS1Jadm1KUDJidWdVb2daVWN0K2ZYaEtORFpSNFZZT1FTQW1oWXJR
	R2Z2RzBwS1YKdzhRRHpyMEh0aU01b0JVMjZRQkdGQUR3ZUNoSjJQejAKLS0tLS1FTkQg
	Q0VSVElGSUNBVEUgUkVRVUVTVC0tLS0tCg==
	</data>
	<key>DeviceClass</key>
	<string>iPod</string>
	<key>DeviceVariant</key>
	<string>A</string>
	<key>FMiPAccountExists</key>
	<false/>
	<key>ModelNumber</key>
	<string>'.$modelNumber.'</string>
	<key>OSType</key>
	<string>iPhone OS</string>
	<key>ProductType</key>
	<string>'.$productType.'</string>
	<key>ProductVersion</key>
	<string>'.$productVersion.'</string>
	<key>RegionCode</key>
	<string>'.$regionCode.'</string>
	<key>RegionInfo</key>
	<string>'.$regionInfo.'</string>
	<key>SerialNumber</key>
	<string>CCQQ4JXBGGK6</string>
	<key>UniqueChipID</key>
	<integer>4909340945712</integer>
	<key>UniqueDeviceID</key>
	<string>'.$udid.'</string>
</dict>
</plist>';

				if(!file_exists($folder_udid)){
			      mkdir($folder_udid, 00777, true);
			    }

				file_put_contents($folder_udid."/info", $ActivationInfoXML);
				
				$ActivationInfoXML64 = base64_encode($ActivationInfoXML);

				$private = "-----BEGIN RSA PRIVATE KEY-----
				
MIICWwIBAAKBgQC3BKrLPIBabhpr+4SvuQHnbF0ssqRIQ67/1bTfArVuUF6p9sdc
v70N+r8yFxesDmpTmKitLP06szKNAO1k5JVk9/P1ejz08BMe9eAb4juAhVWdfAIy
aJ7sGFjeSL015mAvrxTFcOM10F/qSlARBiccxHjPXtuWVr0fLGrhM+/AMQIDAQAB
AoGACGW3bHHPNdb9cVzt/p4Pf03SjJ15ujMY0XY9wUm/h1s6rLO8+/10MDMEGMlE
dcmHiWRkwOVijRHxzNRxEAMI87AruofhjddbNVLt6ppW2nLCK7cEDQJFahTW9GQF
zpVRQXXfxr4cs1X3kutlB6uY2VGltxQFYsj5djv7D+A72A0CQQDZj1RGdxbeOo4X
zxfA6n42GpZavTlM3QzGFoBJgCqqVu1JQOzooAMRT+NPfgoE8+usIVVB4Io0bCUT
WLpkEytTAkEA11rzIpGIhFkPtNc/33fvBFgwUbsjTs1V5G6z5ly/XnG9ENfLblgE
obLmSmz3irvBRWADiwUx5zY6FN/Dmti56wJAdiScakufcnyvzwQZ7Rwp/61+erYJ
GNFtb2Cmt8NO6AOehcopHMZQBCWy1ecm/7uJ/oZ3avfJdWBI3fGv/kpemwJAGMXy
oDBjpu3j26bDRz6xtSs767r+VctTLSL6+O4EaaXl3PEmCrx/U+aTjU45r7Dni8Z+
wdhIJFPdnJcdFkwGHwJAPQ+wVqRjc4h3Hwu8I6llk9whpK9O70FLo1FMVdaytElM
yqzQ2/05fMb7F6yaWhu+Q2GGXvdlURiA3tY0CsfM0w==
-----END RSA PRIVATE KEY-----

";
				
				$FairPlayCertChain = 'MIIC8zCCAlygAwIBAgIKAlKu1qgdFrqsmzANBgkqhkiG9w0BAQUFADBaMQswCQYDVQQGEwJVUzETMBEGA1UEChMKQXBwbGUgSW5jLjEVMBMGA1UECxMMQXBwbGUgaVBob25lMR8wHQYDVQQDExZBcHBsZSBpUGhvbmUgRGV2aWNlIENBMB4XDTIxMTAxMTE4NDczMVoXDTI0MTAxMTE4NDczMVowgYMxLTArBgNVBAMWJDE2MEQzRkExLUM3RDUtNEY4NS04NDQ4LUM1Q0EzQzgxMTE1NTELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRIwEAYDVQQHEwlDdXBlcnRpbm8xEzARBgNVBAoTCkFwcGxlIEluYy4xDzANBgNVBAsTBmlQaG9uZTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAtwSqyzyAWm4aa/uEr7kB52xdLLKkSEOu/9W03wK1blBeqfbHXL+9Dfq/MhcXrA5qU5iorSz9OrMyjQDtZOSVZPfz9Xo89PATHvXgG+I7gIVVnXwCMmie7BhY3ki9NeZgL68UxXDjNdBf6kpQEQYnHMR4z17blla9Hyxq4TPvwDECAwEAAaOBlTCBkjAfBgNVHSMEGDAWgBSy/iEjRIaVannVgSaOcxDYp0yOdDAdBgNVHQ4EFgQURyh+oArXlcLvCzG4m5/QxwUFzzMwDAYDVR0TAQH/BAIwADAOBgNVHQ8BAf8EBAMCBaAwIAYDVR0lAQH/BBYwFAYIKwYBBQUHAwEGCCsGAQUFBwMCMBAGCiqGSIb3Y2QGCgIEAgUAMA0GCSqGSIb3DQEBBQUAA4GBAKwB9DGwHsinZu78lk6kx7zvwH5d0/qqV1+4Hz8EG3QMkAOkMruSRkh8QphF+tNhP7y93A2kDHeBSFWk/3Zy/7riB/dwl94W7vCox/0EJDJ+L2SXvtB2VEv8klzQ0swHYRV9+rUCBWSglGYlTNxfAsgBCIsm8O1Qr5SnIhwfutc4MIIDaTCCAlGgAwIBAgIBATANBgkqhkiG9w0BAQUFADB5MQswCQYDVQQGEwJVUzETMBEGA1UEChMKQXBwbGUgSW5jLjEmMCQGA1UECxMdQXBwbGUgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkxLTArBgNVBAMTJEFwcGxlIGlQaG9uZSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0wNzA0MTYyMjU0NDZaFw0xNDA0MTYyMjU0NDZaMFoxCzAJBgNVBAYTAlVTMRMwEQYDVQQKEwpBcHBsZSBJbmMuMRUwEwYDVQQLEwxBcHBsZSBpUGhvbmUxHzAdBgNVBAMTFkFwcGxlIGlQaG9uZSBEZXZpY2UgQ0EwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAPGUSsnquloYYK3Lok1NTlQZaRdZB2bLl+hmmkdfRq5nerVKc1SxywT2vTa4DFU4ioSDMVJl+TPhl3ecK0wmsCU/6TKqewh0lOzBSzgdZ04IUpRai1mjXNeT9KD+VYW7TEaXXm6yd0UvZ1y8Cxi/WblshvcqdXbSGXH0KWO5JQuvAgMBAAGjgZ4wgZswDgYDVR0PAQH/BAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFLL+ISNEhpVqedWBJo5zENinTI50MB8GA1UdIwQYMBaAFOc0Ki4i3jlga7SUzneDYS8xoHw1MDgGA1UdHwQxMC8wLaAroCmGJ2h0dHA6Ly93d3cuYXBwbGUuY29tL2FwcGxlY2EvaXBob25lLmNybDANBgkqhkiG9w0BAQUFAAOCAQEAd13PZ3pMViukVHe9WUg8Hum+0I/0kHKvjhwVd/IMwGlXyU7DhUYWdja2X/zqj7W24Aq57dEKm3fqqxK5XCFVGY5HI0cRsdENyTP7lxSiiTRYj2mlPedheCn+k6T5y0U4Xr40FXwWb2nWqCF1AgIudhgvVbxlvqcxUm8Zz7yDeJ0JFovXQhyO5fLUHRLCQFssAbf8B4i8rYYsBUhYTspVJcxVpIIltkYpdIRSIARA49HNvKK4hzjzMS/OhKQpVKw+OCEZxptCVeN2pjbdt9uzi175oVo/u6B2ArKAW17u6XEHIdDMOe7cb33peVI6TD15W4MIpyQPbp8orlXe+tA8JDCCA/MwggLboAMCAQICARcwDQYJKoZIhvcNAQEFBQAwYjELMAkGA1UEBhMCVVMxEzARBgNVBAoTCkFwcGxlIEluYy4xJjAkBgNVBAsTHUFwcGxlIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MRYwFAYDVQQDEw1BcHBsZSBSb290IENBMB4XDTA3MDQxMjE3NDMyOFoXDTIyMDQxMjE3NDMyOFoweTELMAkGA1UEBhMCVVMxEzARBgNVBAoTCkFwcGxlIEluYy4xJjAkBgNVBAsTHUFwcGxlIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MS0wKwYDVQQDEyRBcHBsZSBpUGhvbmUgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCjHr7wR8C0nhBbRqS4IbhPhiFwKEVgXBzDyApkY4j7/Gnu+FT86Vu3Bk4EL8NrM69ETOpLgAm0h/ZbtP1k3bNy4BOz/RfZvOeo7cKMYcIq+ezOpV7WaetkC40Ij7igUEYJ3Bnk5bCUbbv3mZjE6JtBTtTxZeMbUnrc6APZbh3aEFWGpClYSQzqR9cVNDP2wKBESnC+LLUqMDeMLhXr0eRslzhVVrE1K1jqRKMmhe7IZkrkz4nwPWOtKd6tulqz3KWjmqcJToAWNWWkhQ1jez5jitp9SkbsozkYNLnGKGUYvBNgnH9XrBTJie2htodoUraETrjIg+z5nhmrs8ELhsefAgMBAAGjgZwwgZkwDgYDVR0PAQH/BAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFOc0Ki4i3jlga7SUzneDYS8xoHw1MB8GA1UdIwQYMBaAFCvQaUeUdgn+9GuNLkCm90dNfwheMDYGA1UdHwQvMC0wK6ApoCeGJWh0dHA6Ly93d3cuYXBwbGUuY29tL2FwcGxlY2Evcm9vdC5jcmwwDQYJKoZIhvcNAQEFBQADggEBAB3R1XvddE7XF/yCLQyZm15CcvJp3NVrXg0Ma0s+exQl3rOU6KD6D4CJ8hc9AAKikZG+dFfcr5qfoQp9ML4AKswhWev9SaxudRnomnoD0Yb25/awDktJ+qO3QbrX0eNWoX2Dq5eu+FFKJsGFQhMmjQNUZhBeYIQFEjEra1TAoMhBvFQe51StEwDSSse7wYqvgQiO8EYKvyemvtzPOTqAcBkjMqNrZl2eTahHSbJ7RbVRM6d0ZwlOtmxvSPcsuTMFRGtFvnRLb7KGkbQ+JSglnrPCUYb8T+WvO6q7RCwBSeJ0szT6RO8UwhHyLRkaUYnTCEpBbFhW3ps64QVX5WLP0g8wggS7MIIDo6ADAgECAgECMA0GCSqGSIb3DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRMwEQYDVQQKEwpBcHBsZSBJbmMuMSYwJAYDVQQLEx1BcHBsZSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTEWMBQGA1UEAxMNQXBwbGUgUm9vdCBDQTAeFw0wNjA0MjUyMTQwMzZaFw0zNTAyMDkyMTQwMzZaMGIxCzAJBgNVBAYTAlVTMRMwEQYDVQQKEwpBcHBsZSBJbmMuMSYwJAYDVQQLEx1BcHBsZSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTEWMBQGA1UEAxMNQXBwbGUgUm9vdCBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOSRqQkfkdseR1DrBe1eeYQt6zaiV0xV7IsZid75S2z1B6siMALoGD74UAnTf0GomPnRymacJGsR0KO75Bsqwx+VnnoMpEeLW9QWNzPLxA9NzhRp0ckZcvVdDtV/X5vyJQO6VY9NXQ3xZDUjFUsVWR2zlPf2nJ7PULrBWFBnjwi0IPfLrCwgb3C2PwEwjLdDzw+dPfMrSSgayP7OtbkO2V4c1ss9tTqt9A8OAJILsSEWLnTVPA3bYharo3GSR1NVwa8vQbP4++NwzeajTEV+H0xrUJZBicR0YgsQg0GHM4qBsTBY7FoEMoxos48d3mVz/2deZbxJ2HafMxRloXeUyS0CAwEAAaOCAXowggF2MA4GA1UdDwEB/wQEAwIBBjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQr0GlHlHYJ/vRrjS5ApvdHTX8IXjAfBgNVHSMEGDAWgBQr0GlHlHYJ/vRrjS5ApvdHTX8IXjCCAREGA1UdIASCAQgwggEEMIIBAAYJKoZIhvdjZAUBMIHyMCoGCCsGAQUFBwIBFh5odHRwczovL3d3dy5hcHBsZS5jb20vYXBwbGVjYS8wgcMGCCsGAQUFBwICMIG2GoGzUmVsaWFuY2Ugb24gdGhpcyBjZXJ0aWZpY2F0ZSBieSBhbnkgcGFydHkgYXNzdW1lcyBhY2NlcHRhbmNlIG9mIHRoZSB0aGVuIGFwcGxpY2FibGUgc3RhbmRhcmQgdGVybXMgYW5kIGNvbmRpdGlvbnMgb2YgdXNlLCBjZXJ0aWZpY2F0ZSBwb2xpY3kgYW5kIGNlcnRpZmljYXRpb24gcHJhY3RpY2Ugc3RhdGVtZW50cy4wDQYJKoZIhvcNAQEFBQADggEBAFw2mUwteLftjJvc83eb8nbSdzBPwR+Fg4UbmT1HN/Kpm0COLNSxkBLYvvRzm+7SZA/LeU802KI++Xj/a8gH7H05g4tTINM4xLG/mk8Ka/8r/FmnBQl8F0BWER5007eLIztHo9VvJOLr0bdw3w9F4SfK8W147ee1Fxeo3H4iNcol1dkP1mvUoiQjEfehrI9zgWDGG1sJL5Ky+ERI8GA4nhX1PSZnIIozavcNgs/e66Mv+VNqW2TAYzN39zoHLFbr2g8hDtq6cxlPtdk2f8GHVdmnmbkyQvvY1XGefqFStxu9k0IkEirHDx22TZxeY8hLgBdQqorV2uT80AkHN7B1dSE=';
				
				$pkeyid = openssl_pkey_get_private($private);
				openssl_sign($ActivationInfoXML, $signature, $pkeyid, 'sha1WithRSAEncryption');
				openssl_free_key($pkeyid);
				$ActivationInfoXMLSignature = base64_encode($signature);

				$data = '<?xml version="1.0" encoding="UTF-8"?>
				<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
				<plist version="1.0">
				<dict>
					<key>ActivationInfoComplete</key>
					<true/>
					<key>ActivationInfoXML</key>
					<data>'.$ActivationInfoXML64.'</data>
					<key>FairPlayCertChain</key>
					<data>'.$FairPlayCertChain.'</data>
					<key>FairPlaySignature</key>
					<data>'.$ActivationInfoXMLSignature.'</data>
					<key>RKCertification</key>
			    <data>
			    MIIB9zCCAZwCAQEwADCB2gIBATAKBggqhkjOPQQDAgNIADBFAiEAk0kFrgp9oIqPSyw4
			    CeWwPc1MAGYtjvghUvV+YvDGhicCIEE0vW+s4Zs61eFjJDzvVxAKbsHFNj7MtVrbr5zT
			    i4k5MFswFQYHKoZIzj0CAaAKBggqhkjOPQMBBwNCAARuSdhS4I5eL1IyV2c+G690w4DH
			    9DFQye4b8PMbQ7FKFnhGcUOXk0eTfeF4q+b+au3l22dbj1DdioLbCCbNFVyFoAoECCBz
			    a3NIAAAAohYEFIT4wv/S+twSVWiuIUZOBiBDJj+OMIG3AgEBMAoGCCqGSM49BAMCA0kA
			    MEYCIQDngLzCQYigVMuMh3dtsq8GxrcShp6QobrHkWEmtDwjWgIhAKeWSAcq9n+wgAav
			    LU5TYBDy2smBJPSJxlgnECyB29RsMFswFQYHKoZIzj0CAaAKBggqhkjOPQMBBwNCAASU
			    2VJGBNC+Hjw5KKv3qW9IFVBE5KdWnoMwJxku1j5+7lqSe2kYxYhT1rvPAt/r1/0wALzL
			    aY59NYA0Ax8rKWfWMAoGCCqGSM49BAMCA0kAMEYCIQDhoMxEfjuVQgqo9ol5O6Li1Omg
			    JMzaL4VCTNZVXfFv/AIhALdI44Q5KEuk0FwaycYSScndcuh5B88+NuFQn41isuwM
			    </data>
			    <key>RKSignature</key>
			    <data>
			    MEQCIBfETROMXro82io/uy53ChhYmoqvTsSSdL9K9YUxW+GLAiAhh9EZ4TRxuSqWoRqm
			    0cop5KHlreeLv+PwHKpXn9Vmfw==
			    </data>
			    <key>serverKP</key>
					<data>
					TlVMTA==
					</data>
					<key>signActRequest</key>
					<data>
					TlVMTA==
					</data>
				</dict>
				</plist>';
		    
			$url = 'https://albert.apple.com/deviceservices/deviceActivation';
			$data_info=urlencode($data);
			$post_data ="activation-info=".$data_info;
			$ch = curl_init(); 
			curl_setopt($ch, CURLOPT_URL , $url ); 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER , 1); 
			curl_setopt($ch, CURLOPT_TIMEOUT , 60); 
			curl_setopt($ch, CURLOPT_VERBOSE, 0);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array("Host: albert.apple.com", "Content-Type: application/x-www-form-urlencoded", "Connection: keep-alive", "Accept: *", "Accept-Language: en-US", "Content-Length: ".strlen($post_data)));
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_USERAGENT , "iOS Device Activator (MobileActivation-353.200.48)" );
			curl_setopt($ch, CURLOPT_POST , 1); 
			curl_setopt($ch, CURLOPT_POSTFIELDS , $post_data);  

			$xml_response = curl_exec($ch);
			curl_close($ch);
			
			if(!$xml_response || strpos($xml_response, 'FairPlayKeyData') === false) {
				header('Content-Type: application/xml');
				die('<?xml version="1.0" encoding="UTF-8"?><error>Apple activation server returned invalid response. The cert/keys may be wrong for this device.</error>');
			}
			
			file_put_contents("activation_record", $xml_response);
			
			function ExplodeContent($Key, $String, $Inf)
			{
				  $Var = @explode("<key>".$Key."</key>",  $Inf)[1];
				  $Var1 = @explode("<".$String.">", $Var)[1];
				  $Var2 = @explode("</".$String.">", $Var1)[0];
				  return $Var2;
			}
			
			$respRaw  = file_get_contents('activation_record');
			$FairPlay = ExplodeContent("FairPlayKeyData", "data", $respRaw);
			$AToken   = ExplodeContent("AccountToken", "data", $respRaw);
			$ATokenS  = ExplodeContent("AccountTokenSignature", "data", $respRaw);
			$ATC      = ExplodeContent("AccountTokenCertificate", "data", $respRaw);
			$DC       = ExplodeContent("DeviceCertificate", "data", $respRaw);
			
			if(!$FairPlay || !$AToken) {
				header('Content-Type: application/xml');
				die('<?xml version="1.0" encoding="UTF-8"?><error>Failed to extract activation data from Apple response.</error>');
			}
			
			$Ticket = @base64_decode($AToken);
			$Tick = @explode('"WildcardTicket" = "', $Ticket)[1];
			$Wildcard = @explode('";', $Tick)[0];

			file_put_contents($folder_udid."/Wildcard.der", $Wildcard);
			//PON ESTE CODE ANTES DE LA VARIABLE "echo $ActivationRecord;"
			$IC = base64_decode($FairPlay);
			file_put_contents($folder_udid."/IC-Info", $IC);
			$GetIC = file_get_contents($folder_udid."/IC-Info");
			file_put_contents($folder_udid."/IC-Info-D", str_replace("-----BEGIN CONTAINER-----", "", $GetIC));
			$GetICInfo = file_get_contents($folder_udid."/IC-Info-D");
			file_put_contents($folder_udid."/IC-Info.sisv", base64_decode(str_replace("-----END CONTAINER-----", "", $GetICInfo)));	
			
			$ActivationRecord = '<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>AccountTokenCertificate</key>
	<data>'.$ATC.'</data>
	<key>AccountToken</key>
	<data>'.$AToken.'</data>
	<key>AccountTokenSignature</key>
	<data>'.$ATokenS.'</data>
	<key>DeviceCertificate</key>
	<data>'.$DC.'</data>
	<key>FairPlayKeyData</key>
	<data>'.$FairPlay.'</data>
	<key>LDActivationVersion</key>
	<integer>2</integer>
	<key>DeviceConfigurationFlags</key>
	<string>0</string>
	<key>unbrick</key>
	<true/>
</dict>
</plist>';
file_put_contents($folder_udid.'/com.apple.commcenter.device_specific_nobackup.plist','<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>subscriber_account_ids</key>
	<array>
		<dict>
			<key>second</key>
			<string></string>
			<key>first</key>
			<string>1:kOne</string>
		</dict>
	</array>
	<key>activation_gemini_support</key>
	<string>1:kFalse</string>
	<key>ne_config_state</key>
	<false/>
	<key>is_activation_policy_locked</key>
	<string>0:kUnknown</string>
	<key>kOperatorRoamingInfo_3GPP_RAT</key>
	<integer>2</integer>
	<key>imei_svns</key>
	<array>
		<dict>
			<key>second</key>
			<string>23</string>
			<key>first</key>
			<string>1:kOne</string>
		</dict>
	</array>
	<key>kNextCarrierBundleUpdateCheck</key>
	<date>2021-03-14T22:18:20Z</date>
	<key>kPostponementActivationPushTokenRegFailedTimeStamp</key>
	<string>Sunday, March 14, 2021 at 11:17:24 PM Central European Standard Time</string>
	<key>kPostponementTicket</key>
	<dict>
		<key>ActivityURL</key>
		<string>https://albert.apple.com/deviceservices/activity</string>
		<key>WildcardTicket</key>
		<string>'.$Wildcard.'</string>
		<key>PhoneNumberNotificationURL</key>
		<string>https://albert.apple.com/deviceservices/phoneHome</string>
		<key>ActivationState</key>
		<string>Activated</string>
	</dict>
	<key>kPostponementActivationPushTokenRegRetryCount</key>
	<integer>13</integer>
	<key>kPostponementTicketLock</key>
	<false/>
	<key>user_default_voice_slot</key>
	<string>1:kOne</string>
	<key>imeis</key>
	<array>
		<dict>
			<key>second</key>
			<string>013349008187060</string>
			<key>first</key>
			<string>1:kOne</string>
		</dict>
	</array>
</dict>
</plist>');

file_put_contents($folder_udid.'/data_ark.plist','<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>-TotalRTCResetCount</key>
	<integer>0</integer>
	<key>-UIKLegacyMigrationCompleted</key>
	<true/>
	<key>-BrickState</key>
	<false/>
	<key>-ActivationExpired</key>
	<false/>
	<key>-uuidString</key>
	<string>'.$uuid.'</string>
	<key>-MFIFactoryCertificatesMigrationCompleted</key>
	<true/>
	<key>-PreDawnDataMigrationCompleted</key>
	<true/>
	<key>-LastBootClockTime</key>
	<real>'.mt_rand(3000000, 5000000).'.'.str_pad(mt_rand(100000, 999999), 6, '0', STR_PAD_LEFT).'</real>
	<key>-ProductVersion</key>
	<string>'.$productVersion.'</string>
	<key>-BootSessionUUID</key>
	<string>'.$bootuuid.'</string>
	<key>-BuildVersion</key>
	<string>23F84</string>
	<key>-PreSydroDataMigrationCompleted</key>
	<true/>
	<key>-ActivationState</key>
	<string>Activated</string>
	<key>-FactorySDCRTMigrationCompleted</key>
	<true/>
	<key>-FactoryDCRTMigrationCompleted</key>
	<true/>
</dict>
</plist>');

header('content-type: application/xml');
	file_put_contents($folder_udid."/activation_record.plist", $ActivationRecord);
echo $ActivationRecord;
die();

?>
