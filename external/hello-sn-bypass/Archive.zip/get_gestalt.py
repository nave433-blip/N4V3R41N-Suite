#!/usr/bin/env python3
"""
get_gestalt.py — download ORIGINAL MobileGestalt.plist from SSH ramdisk.

Binary-safe copy via SFTP/scp (never cat).
Saves next to this script:
  <script_dir>/com.apple.MobileGestalt.plist

Works on Windows / macOS / Linux.

Usage:
  python3 get_gestalt.py
  python get_gestalt.py

Optional env:
  SSHPASS_PASSWORD   default: alpine
  SSH_PORT           default: 2222
  SSH_HOST           default: 127.0.0.1
  IPROXY_LOCAL       default: same as SSH_PORT
  IPROXY_DEVICE      default: 22
  SKIP_IPROXY=1      do not start iproxy

Needs either:
  pip install paramiko
or system ssh/scp (+ sshpass on Unix if using password auth)
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

REMOTE = (
    "/mnt2/containers/Shared/SystemGroup/"
    "systemgroup.com.apple.mobilegestaltcache/Library/Caches/"
    "com.apple.MobileGestalt.plist"
)

HOST = os.environ.get("SSH_HOST", "127.0.0.1")
PORT = int(os.environ.get("SSH_PORT", "2222"))
PASSWORD = os.environ.get("SSHPASS_PASSWORD", "alpine")
USER = os.environ.get("SSH_USER", "root")
IPROXY_LOCAL = int(os.environ.get("IPROXY_LOCAL", str(PORT)))
IPROXY_DEVICE = int(os.environ.get("IPROXY_DEVICE", "22"))
SKIP_IPROXY = os.environ.get("SKIP_IPROXY", "").strip() in ("1", "true", "yes")

SCRIPT_DIR = Path(__file__).resolve().parent
OUT = SCRIPT_DIR / "com.apple.MobileGestalt.plist"


def which(name: str) -> str | None:
    return shutil.which(name)


def start_iproxy() -> subprocess.Popen | None:
    if SKIP_IPROXY:
        return None
    iproxy = which("iproxy")
    if not iproxy:
        # common Windows / tool layouts next to script
        for cand in (
            SCRIPT_DIR / "tools" / "iproxy.exe",
            SCRIPT_DIR / "tools" / "iproxy",
            SCRIPT_DIR / "iproxy.exe",
            SCRIPT_DIR / "iproxy",
        ):
            if cand.is_file():
                iproxy = str(cand)
                break
    if not iproxy:
        print("NOTE: iproxy not found — assuming tunnel already on port", PORT)
        return None

    # kill stale (best-effort; ignore errors on Windows)
    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/F", "/IM", "iproxy.exe"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
        else:
            subprocess.run(
                ["pkill", "-f", f"iproxy {IPROXY_LOCAL} {IPROXY_DEVICE}"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
    except Exception:
        pass

    print(f"Starting: {iproxy} {IPROXY_LOCAL} {IPROXY_DEVICE}")
    proc = subprocess.Popen(
        [iproxy, str(IPROXY_LOCAL), str(IPROXY_DEVICE)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(1.0)
    if proc.poll() is not None:
        print("WARNING: iproxy exited early — is the device connected?")
        return None
    return proc


def download_paramiko(out: Path) -> None:
    import paramiko  # type: ignore

    print(f"SFTP (paramiko) {USER}@{HOST}:{PORT}")
    print(f"  remote: {REMOTE}")
    print(f"  local:  {out}")

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        HOST,
        port=PORT,
        username=USER,
        password=PASSWORD,
        look_for_keys=False,
        allow_agent=False,
        timeout=20,
        banner_timeout=20,
        auth_timeout=20,
    )
    try:
        # confirm exists + size via sftp
        sftp = client.open_sftp()
        try:
            st = sftp.stat(REMOTE)
            remote_size = int(st.st_size)
            sftp.get(REMOTE, str(out))
        finally:
            sftp.close()
    finally:
        client.close()

    local_size = out.stat().st_size
    print(f"remote bytes: {remote_size}")
    print(f"local  bytes: {local_size}")
    if remote_size != local_size:
        raise SystemExit("ERROR: size mismatch after SFTP")
    print("OK: binary copy via SFTP")


def download_scp(out: Path) -> None:
    scp = which("scp")
    ssh = which("ssh")
    if not scp or not ssh:
        raise SystemExit(
            "ERROR: need 'paramiko' (pip install paramiko) "
            "or system scp/ssh in PATH"
        )

    ssh_base = [
        "-o",
        "HostKeyAlgorithms=+ssh-rsa",
        "-o",
        "StrictHostKeyChecking=no",
        "-o",
        "UserKnownHostsFile=/dev/null",
        "-o",
        "PubkeyAuthentication=no",
        "-o",
        "PreferredAuthentications=password",
        "-o",
        "ConnectTimeout=20",
        "-p",
        str(PORT),
    ]

    print(f"SCP {USER}@{HOST}:{PORT}")
    print(f"  remote: {REMOTE}")
    print(f"  local:  {out}")

    sshpass = which("sshpass")
    remote_spec = f"{USER}@{HOST}:{REMOTE}"

    def run(cmd: list[str]) -> None:
        r = subprocess.run(cmd, check=False)
        if r.returncode != 0:
            raise SystemExit(f"ERROR: command failed ({r.returncode}): {' '.join(cmd[:3])}...")

    # size check
    size_cmd = [ssh, *ssh_base, f"{USER}@{HOST}", f"wc -c < '{REMOTE}'"]
    scp_cmd = [
        scp,
        "-o",
        "HostKeyAlgorithms=+ssh-rsa",
        "-o",
        "StrictHostKeyChecking=no",
        "-o",
        "UserKnownHostsFile=/dev/null",
        "-o",
        "PubkeyAuthentication=no",
        "-o",
        "PreferredAuthentications=password",
        "-o",
        "ConnectTimeout=20",
        "-P",
        str(PORT),
        remote_spec,
        str(out),
    ]

    if sshpass:
        size_cmd = [sshpass, "-p", PASSWORD, *size_cmd]
        scp_cmd = [sshpass, "-p", PASSWORD, *scp_cmd]
    else:
        print(
            "WARNING: sshpass not found — scp may prompt for password "
            f"({PASSWORD}). Prefer: pip install paramiko"
        )

    # ensure remote exists / get size
    r = subprocess.run(size_cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(
            f"ERROR: cannot read remote gestalt (is ramdisk mounted?)\n{r.stderr}"
        )
    remote_size = int("".join(ch for ch in r.stdout if ch.isdigit()) or "-1")

    run(scp_cmd)
    local_size = out.stat().st_size
    print(f"remote bytes: {remote_size}")
    print(f"local  bytes: {local_size}")
    if remote_size >= 0 and remote_size != local_size:
        raise SystemExit("ERROR: size mismatch after scp")
    print("OK: binary copy via scp")


def sniff(out: Path) -> None:
    data = out.read_bytes()[:8]
    if data.startswith(b"bplist"):
        kind = "Apple binary property list"
    elif data.startswith(b"<?xml") or data.startswith(b"<plist"):
        kind = "XML plist"
    else:
        kind = f"unknown ({data!r})"
    print(f"file: {kind}")


def main() -> int:
    print("get_gestalt.py — original device MobileGestalt (scp/SFTP, not cat)")
    print(f"save path: {OUT}")

    iproxy_proc = start_iproxy()
    try:
        # prefer paramiko (works well on Windows)
        try:
            import paramiko  # noqa: F401

            download_paramiko(OUT)
        except ImportError:
            download_scp(OUT)

        sniff(OUT)
        print(f"saved: {OUT}")
        return 0
    finally:
        if iproxy_proc is not None and iproxy_proc.poll() is None:
            try:
                iproxy_proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\naborted")
        raise SystemExit(130)
