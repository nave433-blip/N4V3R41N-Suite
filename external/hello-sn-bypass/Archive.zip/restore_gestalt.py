#!/usr/bin/env python3
"""
restore_gestalt.py — upload MobileGestalt.plist to SSH ramdisk.

On device:
  1) rename existing plist -> com.apple.MobileGestalt.plist.bak
  2) place the new plist at the original path

Binary-safe (SFTP/scp — never cat).
Windows / macOS / Linux.

Usage:
  python3 restore_gestalt.py /path/to/com.apple.MobileGestalt.plist
  (or drag & drop the plist onto the .command / .bat)

Optional env:
  SSHPASS_PASSWORD   default: alpine
  SSH_PORT           default: 2222
  SSH_HOST           default: 127.0.0.1
  SKIP_IPROXY=1      do not start iproxy

Prefer:  pip install paramiko
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

REMOTE_DIR = (
    "/mnt2/containers/Shared/SystemGroup/"
    "systemgroup.com.apple.mobilegestaltcache/Library/Caches"
)
REMOTE = f"{REMOTE_DIR}/com.apple.MobileGestalt.plist"
REMOTE_BAK = f"{REMOTE_DIR}/com.apple.MobileGestalt.plist.bak"
STAGE = "/mnt2/root/com.apple.MobileGestalt.plist"

HOST = os.environ.get("SSH_HOST", "127.0.0.1")
PORT = int(os.environ.get("SSH_PORT", "2222"))
PASSWORD = os.environ.get("SSHPASS_PASSWORD", "alpine")
USER = os.environ.get("SSH_USER", "root")
IPROXY_LOCAL = int(os.environ.get("IPROXY_LOCAL", str(PORT)))
IPROXY_DEVICE = int(os.environ.get("IPROXY_DEVICE", "22"))
SKIP_IPROXY = os.environ.get("SKIP_IPROXY", "").strip() in ("1", "true", "yes")

SCRIPT_DIR = Path(__file__).resolve().parent

REMOTE_SH = r"""
set -e
SRC=/mnt2/root/com.apple.MobileGestalt.plist
DIR=/mnt2/containers/Shared/SystemGroup/systemgroup.com.apple.mobilegestaltcache/Library/Caches
DST=$DIR/com.apple.MobileGestalt.plist
BAK=$DIR/com.apple.MobileGestalt.plist.bak

[ -f "$SRC" ] || { echo "ERROR: staged file missing $SRC"; exit 1; }

mkdir -p "$DIR" 2>/dev/null || true

# 1) rename old -> bak (keep previous bak as .bak.old if present)
if [ -f "$DST" ]; then
  rm -f "$BAK.old" 2>/dev/null || true
  if [ -f "$BAK" ]; then
    mv -f "$BAK" "$BAK.old" 2>/dev/null || rm -f "$BAK"
  fi
  if mv -f "$DST" "$BAK" 2>/dev/null; then
    echo "renamed old -> bak"
  else
    echo "direct rename blocked — will swap Caches with bak+new"
  fi
fi

# 2) place new file
if mv -f "$SRC" "$DST" 2>/dev/null || cp "$SRC" "$DST" 2>/dev/null; then
  echo "placed new plist"
else
  echo "direct place blocked — directory swap"
  rm -rf /mnt2/tmp/Caches.new /mnt2/tmp/Caches.old
  mkdir -p /mnt2/tmp/Caches.new
  # keep bak if we already renamed it into DIR, or copy current
  if [ -f "$BAK" ]; then
    cp "$BAK" /mnt2/tmp/Caches.new/com.apple.MobileGestalt.plist.bak 2>/dev/null || true
  elif [ -f "$DST" ]; then
    cp "$DST" /mnt2/tmp/Caches.new/com.apple.MobileGestalt.plist.bak 2>/dev/null || true
  fi
  cp "$SRC" /mnt2/tmp/Caches.new/com.apple.MobileGestalt.plist
  if [ -e "$DIR" ]; then
    mv "$DIR" /mnt2/tmp/Caches.old
  fi
  mv /mnt2/tmp/Caches.new "$DIR"
  rm -rf /mnt2/tmp/Caches.old
  rm -f "$SRC"
  echo "swap done"
fi

chmod 644 "$DST" 2>/dev/null || true
sync
echo "=== VERIFY ==="
ls -la "$DST"
ls -la "$BAK" 2>/dev/null || echo "(no bak — there was no previous file)"
wc -c "$DST"
"""


def which(name: str) -> str | None:
    return shutil.which(name)


def start_iproxy() -> subprocess.Popen | None:
    if SKIP_IPROXY:
        return None
    iproxy = which("iproxy")
    if not iproxy:
        for cand in (
            SCRIPT_DIR / "tools" / "iproxy.exe",
            SCRIPT_DIR / "tools" / "iproxy",
            SCRIPT_DIR / "iproxy.exe",
            SCRIPT_DIR / "iproxy",
        ):
            if cand.is_file():
                iproxy = str(cand)
                break
    if not iproxy:
        print("NOTE: iproxy not found — assuming tunnel already on port", PORT)
        return None

    try:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/F", "/IM", "iproxy.exe"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
        else:
            subprocess.run(
                ["pkill", "-f", f"iproxy {IPROXY_LOCAL} {IPROXY_DEVICE}"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
    except Exception:
        pass

    print(f"Starting: {iproxy} {IPROXY_LOCAL} {IPROXY_DEVICE}")
    proc = subprocess.Popen(
        [iproxy, str(IPROXY_LOCAL), str(IPROXY_DEVICE)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(1.0)
    if proc.poll() is not None:
        print("WARNING: iproxy exited early")
        return None
    return proc


def connect_paramiko():
    import paramiko  # type: ignore

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        HOST,
        port=PORT,
        username=USER,
        password=PASSWORD,
        look_for_keys=False,
        allow_agent=False,
        timeout=20,
        banner_timeout=20,
        auth_timeout=20,
    )
    return client


def upload_and_restore_paramiko(local: Path) -> None:
    client = connect_paramiko()
    try:
        sftp = client.open_sftp()
        try:
            print(f"SFTP upload -> {STAGE}")
            sftp.put(str(local), STAGE)
        finally:
            sftp.close()

        print("Rename old->bak and place new on device...")
        _stdin, stdout, stderr = client.exec_command("/bin/sh -s", timeout=120)
        _stdin.write(REMOTE_SH)
        _stdin.channel.shutdown_write()
        out = stdout.read().decode("utf-8", "replace")
        err = stderr.read().decode("utf-8", "replace")
        code = stdout.channel.recv_exit_status()
        if out.strip():
            print(out.rstrip())
        if err.strip():
            print(err.rstrip(), file=sys.stderr)
        if code != 0:
            raise SystemExit(f"ERROR: remote script exit {code}")

        # verify size
        sftp = client.open_sftp()
        try:
            remote_size = int(sftp.stat(REMOTE).st_size)
        finally:
            sftp.close()
        local_size = local.stat().st_size
        print(f"local  bytes: {local_size}")
        print(f"remote bytes: {remote_size}")
        if local_size != remote_size:
            raise SystemExit("ERROR: size mismatch after restore")
        print("OK: restored")
        print(f"  live: {REMOTE}")
        print(f"  bak:  {REMOTE_BAK}")
    finally:
        client.close()


def sshpass_prefix() -> list[str]:
    sp = which("sshpass")
    return [sp, "-p", PASSWORD] if sp else []


def ssh_base() -> list[str]:
    return [
        "-o",
        "HostKeyAlgorithms=+ssh-rsa",
        "-o",
        "StrictHostKeyChecking=no",
        "-o",
        "UserKnownHostsFile=/dev/null",
        "-o",
        "PubkeyAuthentication=no",
        "-o",
        "PreferredAuthentications=password",
        "-o",
        "ConnectTimeout=20",
    ]


def upload_and_restore_scp(local: Path) -> None:
    scp = which("scp")
    ssh = which("ssh")
    if not scp or not ssh:
        raise SystemExit(
            "ERROR: install paramiko (`pip install paramiko`) "
            "or put scp/ssh in PATH"
        )

    pre = sshpass_prefix()
    if not pre:
        print("WARNING: no sshpass — may prompt for password; prefer paramiko")

    print(f"SCP upload -> {STAGE}")
    cmd = [
        *pre,
        scp,
        *ssh_base(),
        "-P",
        str(PORT),
        str(local),
        f"{USER}@{HOST}:{STAGE}",
    ]
    r = subprocess.run(cmd)
    if r.returncode != 0:
        raise SystemExit("ERROR: scp upload failed")

    print("Rename old->bak and place new on device...")
    r = subprocess.run(
        [
            *pre,
            ssh,
            *ssh_base(),
            "-p",
            str(PORT),
            f"{USER}@{HOST}",
            "/bin/sh -s",
        ],
        input=REMOTE_SH.encode(),
    )
    if r.returncode != 0:
        raise SystemExit(f"ERROR: remote restore failed ({r.returncode})")

    # size check
    r = subprocess.run(
        [
            *pre,
            ssh,
            *ssh_base(),
            "-p",
            str(PORT),
            f"{USER}@{HOST}",
            f"wc -c < '{REMOTE}'",
        ],
        capture_output=True,
        text=True,
    )
    remote_size = int("".join(c for c in (r.stdout or "") if c.isdigit()) or "-1")
    local_size = local.stat().st_size
    print(f"local  bytes: {local_size}")
    print(f"remote bytes: {remote_size}")
    if remote_size >= 0 and remote_size != local_size:
        raise SystemExit("ERROR: size mismatch after restore")
    print("OK: restored")
    print(f"  live: {REMOTE}")
    print(f"  bak:  {REMOTE_BAK}")


def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[1] in ("-h", "--help"):
        print("Usage: restore_gestalt.py <com.apple.MobileGestalt.plist>")
        print("Drag & drop the plist onto this script / .bat / .command")
        return 1 if len(argv) < 2 else 0

    local = Path(argv[1]).expanduser().resolve()
    if not local.is_file():
        print(f"ERROR: not a file: {local}", file=sys.stderr)
        return 1

    head = local.read_bytes()[:8]
    if not (head.startswith(b"bplist") or head.startswith(b"<?xml") or head.startswith(b"<plist")):
        print("WARNING: file does not look like a plist — continuing anyway")

    print("restore_gestalt.py")
    print(f"local:  {local} ({local.stat().st_size} bytes)")
    print(f"device: {REMOTE}")
    print(f"bak:    {REMOTE_BAK}")

    iproxy_proc = start_iproxy()
    try:
        try:
            import paramiko  # noqa: F401

            upload_and_restore_paramiko(local)
        except ImportError:
            upload_and_restore_scp(local)
        return 0
    finally:
        if iproxy_proc is not None and iproxy_proc.poll() is None:
            try:
                iproxy_proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv))
    except KeyboardInterrupt:
        print("\naborted")
        raise SystemExit(130)
